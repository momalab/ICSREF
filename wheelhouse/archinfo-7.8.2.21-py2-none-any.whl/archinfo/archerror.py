class ArchError(Exception):
    pass
