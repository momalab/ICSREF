version = (1, 6, 6)
version_string = ".".join(map(str,version))
release_date = "2018.02.12"
