"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.3.1'
__revision__ = None
__date__ = 'Sun Sep  6 07:49:58 2015'

