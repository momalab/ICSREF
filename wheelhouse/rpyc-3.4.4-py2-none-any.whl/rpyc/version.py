version = (3, 4, 4)
version_string = "3.4.4"
release_date = "2017.08.07"
