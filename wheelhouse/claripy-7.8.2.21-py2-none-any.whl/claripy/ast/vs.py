from .bits import Bits

class VS(Bits):
    pass
