from ..ast.base import Base

class Int(Base):
    pass
