Pymodbus aims to be a fully implemented modbus protocol stack 
implemented using twisted.  Its orignal goal was to allow simulation 
of thousands of modbus devices on a single machine for monitoring 
software testing.


