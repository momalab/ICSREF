from . import SimIRStmt

class SimIRStmt_MBE(SimIRStmt):
    def _execute(self):
        pass
