"""
These procedures implement internal functions in the uClibc libc implementation
"""
