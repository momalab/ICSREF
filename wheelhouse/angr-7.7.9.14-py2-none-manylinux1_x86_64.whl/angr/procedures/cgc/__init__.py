"""
These procedures implement system calls for the cgc DECREE platform
"""
