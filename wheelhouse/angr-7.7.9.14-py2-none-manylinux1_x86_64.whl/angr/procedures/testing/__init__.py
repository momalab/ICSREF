"""
These procedures are used in the angr test suite. I'm like 90% sure they're unused at this point.
"""
