"""
These procedures implement functions described in POSIX.1
"""
