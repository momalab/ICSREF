from .close import close

# :/
class closedir(close):
    pass
